# NginxFacil
NginxFacil Lite - Auto Instalador Nginx ISPConfig

Requer servidor com Debian 8 64

# Comando para instalar:

apt-get update && apt-get install git -y && git clone https://github.com/robson-lopes/nginxfacil.git && cd nginxfacil && chmod 755 instalador.sh.x && ./instalador.sh.x
